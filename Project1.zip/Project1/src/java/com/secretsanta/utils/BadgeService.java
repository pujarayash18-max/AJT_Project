/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.utils;

import java.util.*;

/**
 * BadgeService calculates badges for a user based on different activity counts.
 *
 * You can call evaluateBadges() from any servlet (wishlist, story, challenge, polls etc.)
 */
public class BadgeService {

    /**
     * Evaluates all badges for a user and returns a list of earned badge names.
     *
     * @param wishlistCount number of wishlist items the user added
     * @param storyCount number of stories submitted
     * @param hintsGiven number of hints written
     * @param guessesMade number of guesses submitted
     * @param challengesCompleted number of challenges the user has solved
     * @param pollVotes number of poll votes submitted
     * @param messagesSent number of anonymous messages sent
     * @return a List of badge names the user earned
     */
    public static List<String> evaluateBadges(
            int wishlistCount,
            int storyCount,
            int hintsGiven,
            int guessesMade,
            int challengesCompleted,
            int pollVotes,
            int messagesSent
    ) {
        List<String> badges = new ArrayList<>();

        // ----------------------------------------------------
        // Wishlist badges
        // ----------------------------------------------------
        if (wishlistCount >= 1)
            badges.add("Wishlist Starter");
        if (wishlistCount >= 5)
            badges.add("Gift Expert");
        if (wishlistCount >= 10)
            badges.add("Santa's Favorite Shopper");

        // ----------------------------------------------------
        // Story badges
        // ----------------------------------------------------
        if (storyCount >= 1)
            badges.add("Story Teller");
        if (storyCount >= 5)
            badges.add("Creative Elf");

        // ----------------------------------------------------
        // Hint badges
        // ----------------------------------------------------
        if (hintsGiven >= 1)
            badges.add("Helpful Elf");
        if (hintsGiven >= 5)
            badges.add("Master Hint Giver");

        // ----------------------------------------------------
        // Guess badges
        // ----------------------------------------------------
        if (guessesMade >= 1)
            badges.add("Guess Beginner");
        if (guessesMade >= 3)
            badges.add("Sharp Mind");
        if (guessesMade >= 10)
            badges.add("Guessing Champion");

        // ----------------------------------------------------
        // Challenge badges
        // ----------------------------------------------------
        if (challengesCompleted >= 1)
            badges.add("Challenge Rookie");
        if (challengesCompleted >= 5)
            badges.add("Holiday Hero");
        if (challengesCompleted >= 10)
            badges.add("Legendary Santa Solver");

        // ----------------------------------------------------
        // Poll badges
        // ----------------------------------------------------
        if (pollVotes >= 1)
            badges.add("Poll Participant");
        if (pollVotes >= 10)
            badges.add("Community Voice");

        // ----------------------------------------------------
        // Messaging badges
        // ----------------------------------------------------
        if (messagesSent >= 1)
            badges.add("Secret Messenger");
        if (messagesSent >= 5)
            badges.add("Santa Communicator");

        // ----------------------------------------------------
        // Special multi-activity badge
        // ----------------------------------------------------
        if (wishlistCount > 0 &&
            storyCount > 0 &&
            hintsGiven > 0 &&
            guessesMade > 0 &&
            challengesCompleted > 0)
        {
            badges.add("All-Round Santa");
        }

        return badges;
    }
}
