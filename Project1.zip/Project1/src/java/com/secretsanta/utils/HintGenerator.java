/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author yash
 */
package com.secretsanta.utils;

import java.util.*;

/**
 * Utility class that generates fun hints for the Secret Santa game.
 * Hints are generated based on available user information.
 */
public class HintGenerator {

    private static final Random random = new Random();

    // ----------------------------------------------------------
    // MAIN METHOD: Generate a hint based on available data
    // ----------------------------------------------------------
    public static String generateHint(String name, String email, List<String> wishlistItems, String storyText) {

        List<String> possibleHints = new ArrayList<>();

        // ------------------------------
        // Name-based hints
        // ------------------------------
        if (name != null && !name.isEmpty()) {
            possibleHints.add("Their name begins with the letter '" + name.charAt(0) + "'.");
            possibleHints.add("Their name has " + name.length() + " letters.");
            possibleHints.add("Their name ends with '" + name.charAt(name.length() - 1) + "'.");
        }

        // ------------------------------
        // Email-based hints
        // ------------------------------
        if (email != null && email.contains("@")) {
            String domain = email.substring(email.indexOf("@") + 1);
            possibleHints.add("Their email provider is: " + domain + ".");
            possibleHints.add("Their email starts with '" + email.charAt(0) + "'.");
        }

        // ------------------------------
        // Wishlist-based hints
        // ------------------------------
        if (wishlistItems != null && !wishlistItems.isEmpty()) {
            String item = wishlistItems.get(random.nextInt(wishlistItems.size()));
            possibleHints.add("They might like something related to: " + item + ".");
            possibleHints.add("One thing they want starts with '" + item.charAt(0) + "'.");
        }

        // ------------------------------
        // Story-based hints
        // ------------------------------
        if (storyText != null && !storyText.isEmpty()) {
            possibleHints.add("Their story reveals they are someone thoughtful.");
            possibleHints.add("They shared a story, maybe it contains clues!");
            possibleHints.add("Their story mentions: \"" + getRandomWord(storyText) + "\".");
        }

        // ------------------------------
        // Fallback hint if nothing available
        // ------------------------------
        if (possibleHints.isEmpty()) {
            return "They prefer to stay mysterious… but they are part of this Secret Santa!";
        }

        return possibleHints.get(random.nextInt(possibleHints.size()));
    }

    // ----------------------------------------------------------
    // Extract a random word from story text
    // ----------------------------------------------------------
    private static String getRandomWord(String text) {
        String[] words = text.split("\\s+");
        if (words.length == 0) return "something interesting";
        return words[random.nextInt(words.length)];
    }
}

