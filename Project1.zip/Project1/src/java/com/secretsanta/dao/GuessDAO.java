/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
/*
 * In com.secretsanta.dao package
 */
import com.secretsanta.models.Guess;
import com.secretsanta.utils.DBConnection; // Assuming this utility exists

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GuessDAO {

    // INSERT NEW GUESS (correct = null → pending)
    public boolean submitGuess(Guess guess) {
        String sql = "INSERT INTO guesses (user_id, guessed_name, correct) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, guess.getUserId());
            ps.setString(2, guess.getGuessedName());

            // handle Boolean correctly
            if (guess.getCorrect() == null) {
                ps.setNull(3, Types.BOOLEAN);
            } else {
                ps.setBoolean(3, guess.getCorrect());
            }

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // GET USER'S GUESSES
    public List<Guess> getGuessesForUser(int userId) {
        List<Guess> list = new ArrayList<>();

        String sql = "SELECT * FROM guesses WHERE user_id=? ORDER BY id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Boolean correct = null;
                Object correctObj = rs.getObject("correct");

                if (correctObj != null) {
                    correct = rs.getBoolean("correct");
                }

                list.add(new Guess(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("guessed_name"),
                        correct   // may be null
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}