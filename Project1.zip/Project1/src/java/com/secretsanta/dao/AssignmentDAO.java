/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.Assignment;
import com.secretsanta.utils.DBConnection;
import java.sql.*;

public class AssignmentDAO {

    public boolean assignSanta(Assignment a) {
        String sql = "INSERT INTO assignments(giver_id, receiver_id) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, a.getGiverId());
            ps.setInt(2, a.getReceiverId());
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public int getReceiverForUser(int giverId) {
        String sql = "SELECT receiver_id FROM assignments WHERE giver_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, giverId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) return rs.getInt("receiver_id");

        } catch (Exception e) { e.printStackTrace(); }
        return -1;
    }
}
