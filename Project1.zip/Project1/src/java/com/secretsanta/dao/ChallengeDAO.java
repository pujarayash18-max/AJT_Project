/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.*;
import com.secretsanta.utils.DBConnection;
import java.sql.*;
import java.util.*;

public class ChallengeDAO {

    public boolean addChallenge(Challenge challenge) {
        String sql = "INSERT INTO challenges(title, description) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, challenge.getTitle());
            ps.setString(2, challenge.getDescription());
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public List<Challenge> getAllChallenges() {
        List<Challenge> list = new ArrayList<>();
        String sql = "SELECT * FROM challenges";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Challenge(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}