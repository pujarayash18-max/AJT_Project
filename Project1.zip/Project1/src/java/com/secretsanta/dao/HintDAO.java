/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.Hint;
import com.secretsanta.utils.DBConnection;
import java.sql.*;
import java.util.*;

public class HintDAO {

    public boolean addHint(Hint hint) {
        String sql = "INSERT INTO hints(user_id, hint_text) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, hint.getUserId());
            ps.setString(2, hint.getHintText());
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public List<Hint> getHintsForUser(int userId) {
        List<Hint> list = new ArrayList<>();
        String sql = "SELECT * FROM hints WHERE user_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Hint(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("hint_text")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
