/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.ChallengeSubmission;
import com.secretsanta.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChallengeSubmissionDAO {

    
    public boolean submit(ChallengeSubmission submission) {

        String sql = "INSERT INTO challenge_submissions (user_id, challenge_id, submission_text, submitted_at) " +
                     "VALUES (?, ?, ?, NOW())";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, submission.getUserId());
            ps.setInt(2, submission.getChallengeId());
            ps.setString(3, submission.getSubmissionText());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


   
    public List<ChallengeSubmission> getSubmissionsByUser(int userId) {

        List<ChallengeSubmission> list = new ArrayList<>();
        String sql = "SELECT * FROM challenge_submissions WHERE user_id = ? ORDER BY submitted_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChallengeSubmission(
                        rs.getInt("user_id"),
                        rs.getInt("challenge_id"),
                        rs.getString("submission_text"),
                        rs.getTimestamp("submitted_at")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    
    public List<ChallengeSubmission> getSubmissionsForChallenge(int challengeId) {

        List<ChallengeSubmission> list = new ArrayList<>();
        String sql = "SELECT * FROM challenge_submissions WHERE challenge_id = ? ORDER BY submitted_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, challengeId);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChallengeSubmission(
                        rs.getInt("user_id"),
                        rs.getInt("challenge_id"),
                        rs.getString("submission_text"),
                        rs.getTimestamp("submitted_at")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    // -------------------------------------------------------------
    // Get ALL submissions (Useful for admin)
    // -------------------------------------------------------------
    public List<ChallengeSubmission> getAllSubmissions() {

        List<ChallengeSubmission> list = new ArrayList<>();
        String sql = "SELECT * FROM challenge_submissions ORDER BY submitted_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChallengeSubmission(
                        rs.getInt("user_id"),
                        rs.getInt("challenge_id"),
                        rs.getString("submission_text"),
                        rs.getTimestamp("submitted_at")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
