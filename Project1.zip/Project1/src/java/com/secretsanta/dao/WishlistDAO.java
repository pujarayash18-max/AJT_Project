/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.WishlistItem;
import com.secretsanta.utils.DBConnection;
import java.sql.*;
import java.util.*;

public class WishlistDAO {

    public boolean addItem(WishlistItem item) {
        String sql = "INSERT INTO wishlist(user_id, item_name, item_url, notes) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, item.getUserId());
            ps.setString(2, item.getItemName());
            ps.setString(3, item.getItemUrl());
            ps.setString(4, item.getNotes());
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public List<WishlistItem> getUserWishlist(int userId) {
        List<WishlistItem> list = new ArrayList<>();
        String sql = "SELECT * FROM wishlist WHERE user_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new WishlistItem(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("item_name"),
                        rs.getString("item_url"),
                        rs.getString("notes")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}