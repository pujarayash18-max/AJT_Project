/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.AnonMessage;
import com.secretsanta.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnonMessageDAO {

    public boolean sendMessage(AnonMessage m) {
        String sql = "INSERT INTO anon_messages(sender_id, receiver_id, message) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, m.getSenderId());
            ps.setInt(2, m.getReceiverId());
            ps.setString(3, m.getMessage());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<AnonMessage> getMessagesForUser(int userId) {
        List<AnonMessage> list = new ArrayList<>();

        String sql = "SELECT id, sender_id, receiver_id, message, sent_at "
                    + "FROM anon_messages WHERE receiver_id = ? ORDER BY sent_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                AnonMessage msg = new AnonMessage(
                        rs.getInt("id"),
                        rs.getInt("sender_id"),
                        rs.getInt("receiver_id"),
                        rs.getString("message"),
                        rs.getTimestamp("sent_at")
                );

                list.add(msg);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}