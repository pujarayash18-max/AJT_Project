/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.Story;
import com.secretsanta.utils.DBConnection;
import java.sql.*;
import java.util.*;

public class StoryDAO {

    public boolean addStory(Story story) {
        String sql = "INSERT INTO stories(user_id, story_text) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, story.getUserId());
            ps.setString(2, story.getStoryText());
            return ps.executeUpdate() > 0;

        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public List<Story> getAllStories() {
        List<Story> list = new ArrayList<>();
        String sql = "SELECT * FROM stories ORDER BY id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Story(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("story_text")
                ));
            }

        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}