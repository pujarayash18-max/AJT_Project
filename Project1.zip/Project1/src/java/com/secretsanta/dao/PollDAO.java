/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.dao;

/**
 *
 * @author yash
 */
import com.secretsanta.models.*;
import com.secretsanta.utils.DBConnection;

import java.sql.*;
import java.util.*;

public class PollDAO {

    // Create poll
    public int createPoll(Poll poll) {

        String sql = "INSERT INTO polls(question, description) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, poll.getQuestion());
            ps.setString(2, poll.getDescription());

            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) 
                return keys.getInt(1);

        } catch (Exception e) { 
            e.printStackTrace();
        }

        return -1;
    }

    // Add poll option
    public boolean addOption(PollOption opt) {

        String sql = "INSERT INTO poll_options(poll_id, option_text) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, opt.getPollId());
            ps.setString(2, opt.getOptionText());

            return ps.executeUpdate() > 0;

        } catch (Exception e) { 
            e.printStackTrace();
        }

        return false;
    }

    // Get options for poll
    public List<PollOption> getOptions(int pollId) {

        List<PollOption> list = new ArrayList<>();

        String sql = "SELECT * FROM poll_options WHERE poll_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, pollId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                list.add(new PollOption(
                        rs.getInt("id"),
                        rs.getInt("poll_id"),
                        rs.getString("option_text"),   // FIXED COLUMN NAME
                        rs.getInt("votes")
                ));
            }

        } catch (Exception e) { 
            e.printStackTrace();
        }

        return list;
    }

    // Vote on an option
    public boolean voteOption(int optionId) {

        String sql = "UPDATE poll_options SET votes = votes + 1 WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, optionId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) { 
            e.printStackTrace();
        }

        return false;
    }
}