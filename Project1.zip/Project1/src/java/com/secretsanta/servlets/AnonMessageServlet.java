/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.AnonMessageDAO;
import com.secretsanta.models.AnonMessage;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;

public class AnonMessageServlet extends HttpServlet {

    private final AnonMessageDAO anonMessageDAO = new AnonMessageDAO();
    // Use 0 or another defined constant to signify an ANONYMOUS SENDER
    private static final int ANONYMOUS_SENDER_ID = 0; 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User sender = (session != null) ? (User) session.getAttribute("user") : null;

        if (sender == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // It's good practice to wrap Integer.parseInt in a try-catch 
        // for robustness, but we'll stick to the original style for minimal change.
        int receiverId = Integer.parseInt(request.getParameter("receiverId"));
        String message = request.getParameter("message");

        if (message == null || message.trim().isEmpty()) {
            // Redirect back with an error parameter
            response.sendRedirect("AnonInboxServlet?error=empty"); 
            return;
        }

        // CORRECTION: Use ANONYMOUS_SENDER_ID instead of sender.getId() 
        // to ensure anonymity and prevent the sender from tracking the message
        // via their own ID if the system were misconfigured.
        AnonMessage msg = new AnonMessage(
                ANONYMOUS_SENDER_ID, // Fixed to 0 for anonymous sending
                receiverId,
                message.trim()
        );

        boolean success = anonMessageDAO.sendMessage(msg);

        if (success) {
            // Redirect back to inbox of the sender
            response.sendRedirect("AnonInboxServlet?sent=1");
        } else {
            response.sendRedirect("AnonInboxServlet?error=db");
        }
    }
}