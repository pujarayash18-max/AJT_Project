/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.AnonMessageDAO;
import com.secretsanta.dao.AssignmentDAO;
import com.secretsanta.models.AnonMessage;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AnonMessageServlet extends HttpServlet {

    private final AnonMessageDAO anonMessageDAO = new AnonMessageDAO();
    private final AssignmentDAO assignmentDAO = new AssignmentDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // FIX: use correct attribute "user"
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Get receiverId from form (optional)
        int receiverId = -1;
        String receiverParam = request.getParameter("receiverId");

        if (receiverParam != null && !receiverParam.isEmpty()) {
            try {
                receiverId = Integer.parseInt(receiverParam);
            } catch (NumberFormatException ignored) {}
        }

        // If no receiverId is supplied, use assignment table
        if (receiverId == -1) {
            receiverId = assignmentDAO.getReceiverForUser(user.getId());
            if (receiverId == -1) {
                request.setAttribute("error", "No assigned receiver found for you.");
                request.getRequestDispatcher("anon_inbox.jsp").forward(request, response);
                return;
            }
        }

        // Save the message
        String messageText = request.getParameter("message");
        AnonMessage message = new AnonMessage(user.getId(), receiverId, messageText);

        anonMessageDAO.sendMessage(message);

        response.sendRedirect(request.getContextPath() + "/AnonInboxServlet");
    }

    @Override
    public String getServletInfo() {
        return "Handles anonymous message sending.";
    }
}
