/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.StoryDAO;
import com.secretsanta.models.Story;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class StoryServlet extends HttpServlet {

    private final StoryDAO storyDAO = new StoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Ensure user is logged in
        if (request.getSession(false) == null || request.getSession(false).getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 1. Fetch all stories
        java.util.List<Story> allStories = storyDAO.getAllStories();
        
        // 2. Set the list in the request scope
        request.setAttribute("stories", allStories);
        
        // 3. Forward the request to stories.jsp for display
        request.getRequestDispatcher("stories.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // story text comes from textarea name="storyText"
        String storyText = request.getParameter("storyText");

        Story story = new Story(user.getId(), storyText);
        
        // Add the story
        storyDAO.addStory(story);

        // Redirect to the servlet's doGet method to display the updated list.
        // This is known as the Post/Redirect/Get pattern.
        response.sendRedirect("StoryServlet"); 
    }

    @Override
    public String getServletInfo() {
        return "Story submission servlet and display controller";
    }
}