package com.secretsanta.servlets;

import com.secretsanta.dao.GuessDAO;
import com.secretsanta.models.Guess;
import com.secretsanta.models.User; // Ensure User is imported
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class GuessServlet extends HttpServlet {

    private final GuessDAO guessDAO = new GuessDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // show guess page with user's previous guesses
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user == null) {
            // Use context path if mapped outside root, but simpler redirect is usually fine for internal pages
            response.sendRedirect("login.jsp"); 
            return;
        }

        List<Guess> guesses = guessDAO.getGuessesForUser(user.getId());
        request.setAttribute("guesses", guesses);
        // Forward to the JSP, keeping the request attributes
        request.getRequestDispatcher("/guess_game.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // submit a new guess
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String guessedName = request.getParameter("guessName");
        if (guessedName == null || guessedName.trim().isEmpty()) {
            request.setAttribute("error", "Please enter a name to guess.");
            // Re-call doGet to display error message and current guesses
            doGet(request, response);
            return;
        }

        // Create new Guess with correct = null -> pending
        Guess guess = new Guess(user.getId(), guessedName.trim(), null); 
        guessDAO.submitGuess(guess);

        // Post/Redirect/Get: Redirect to doGet to show the updated list
        response.sendRedirect("GuessServlet"); 
    }
}