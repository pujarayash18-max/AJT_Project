/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.UserDAO;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class SignupServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("signup.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO userDAO = new UserDAO();

        // Check existing email
        if (userDAO.getUserByEmail(email) != null) {
            request.setAttribute("error", "Email already exists. Please login.");
            request.getRequestDispatcher("signup.jsp").forward(request, response);
            return;
        }

        // Create user (default role = user)
        User newUser = new User(name, email, password, "user");
        boolean result = userDAO.register(newUser);

        if (!result) {
            request.setAttribute("error", "Signup failed. Try again!");
            request.getRequestDispatcher("signup.jsp").forward(request, response);
            return;
        }

        // ✔ After signup, redirect to login page
        response.sendRedirect("login.jsp?msg=Account created! Please login.");
    }

    @Override
    public String getServletInfo() {
        return "Signup servlet that does not auto-login";
    }
}
