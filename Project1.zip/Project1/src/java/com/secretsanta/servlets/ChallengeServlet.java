/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.ChallengeSubmissionDAO;
import com.secretsanta.models.ChallengeSubmission;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class ChallengeServlet extends HttpServlet {

    private final ChallengeSubmissionDAO submissionDAO = new ChallengeSubmissionDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            int challengeId = Integer.parseInt(request.getParameter("challengeId"));
            String answer = request.getParameter("answer");

            // ✔ Uses the correct constructor (3 parameters)
            ChallengeSubmission submission = new ChallengeSubmission(
                    user.getId(),
                    challengeId,
                    answer
            );

            submissionDAO.submit(submission);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Could not submit challenge.");
            request.getRequestDispatcher("challenges.jsp").forward(request, response);
            return;
        }

        // ✔ Redirect safely
        response.sendRedirect(request.getContextPath() + "/challenges.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Challenge submission handler";
    }
}
