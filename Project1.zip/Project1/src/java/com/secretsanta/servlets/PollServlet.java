/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.PollDAO;
import com.secretsanta.models.Poll;
import com.secretsanta.models.PollOption;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class PollServlet extends HttpServlet {

    private final PollDAO pollDAO = new PollDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("admin/admin_polls.jsp"); // No GET handling
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // --- AUTH CHECK ---
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if (!"admin".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect("dashboard.jsp");
            return;
        }

        // --- READ FORM DATA ---
        String question = request.getParameter("question");
        String description = request.getParameter("description");
        String optionsRaw = request.getParameter("options");

        if (description == null) description = "";

        // CREATE POLL
        int pollId = pollDAO.createPoll(new Poll(question, description));

        // ADD OPTIONS
        if (pollId != -1 && optionsRaw != null) {
            String[] opts = optionsRaw.split(",");
            for (String o : opts) {
                String text = o.trim();
                if (!text.isEmpty()) {
                    pollDAO.addOption(new PollOption(pollId, text));
                }
            }
        }

        response.sendRedirect("admin/admin_polls.jsp");
    }
}
