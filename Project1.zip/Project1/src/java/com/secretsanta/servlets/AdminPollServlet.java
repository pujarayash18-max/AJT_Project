/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.PollDAO;
import com.secretsanta.models.Poll;
import com.secretsanta.models.PollOption;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AdminPollServlet extends HttpServlet {

    private final PollDAO pollDAO = new PollDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Only admin can open poll manager
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        response.sendRedirect(request.getContextPath() + "/admin/admin_polls.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Admin check
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Read form inputs
        String question = request.getParameter("question");
        String description = request.getParameter("description");
        String options = request.getParameter("options");  // comma-separated

        if (question == null || question.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/admin_polls.jsp?msg=Invalid+question");
            return;
        }

        // Create poll
        Poll poll = new Poll(question.trim(), description != null ? description.trim() : "");
        int pollId = pollDAO.createPoll(poll);

        // Add options to poll
        if (pollId != -1 && options != null) {
            String[] parts = options.split(",");
            for (String o : parts) {
                String text = o.trim();
                if (!text.isEmpty()) {
                    pollDAO.addOption(new PollOption(pollId, text));
                }
            }
        }

        // Redirect back to admin panel
        response.sendRedirect(request.getContextPath() + "/admin/admin_polls.jsp?msg=Poll+Created+Successfully");
    }

    @Override
    public String getServletInfo() {
        return "Admin Poll Management Servlet";
    }
}
