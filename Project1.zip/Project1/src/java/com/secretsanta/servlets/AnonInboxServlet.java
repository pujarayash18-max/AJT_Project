package com.secretsanta.servlets;

import com.secretsanta.dao.AnonMessageDAO;
import com.secretsanta.dao.UserDAO;
import com.secretsanta.models.AnonMessage;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class AnonInboxServlet extends HttpServlet {

    private final AnonMessageDAO anonMessageDAO = new AnonMessageDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Load messages for logged-in user
        List<AnonMessage> messages = anonMessageDAO.getMessagesForUser(user.getId());

        // DEBUG logging removed for final code

        // AJAX refresh (CORRECTION: Return raw HTML instead of JSON)
        if ("1".equals(request.getParameter("ajax"))) {
            
            // Set content type to HTML/text
            response.setContentType("text/html;charset=UTF-8"); 
            PrintWriter out = response.getWriter();

            StringBuilder htmlBuilder = new StringBuilder();
            
            if (messages.isEmpty()) {
                htmlBuilder.append("<p class=\"text-muted\">No messages yet.</p>");
            } else {
                for (AnonMessage m : messages) {
                    // Manually build the HTML structure for each message
                    htmlBuilder.append("<div class=\"mb-3 p-3 border rounded bg-light\">")
                               .append("<p><strong>From:</strong> Anonymous</p>")
                               
                               // IMPORTANT: HTML escape the message content to prevent XSS (though String.replace below is very basic)
                               .append("<p>").append(htmlEscape(m.getMessage())).append("</p>") 
                               
                               .append("<small class=\"text-muted\">")
                               .append("At: ").append(m.getTimestamp())
                               .append("</small>")
                               .append("</div>");
                }
            }
            
            out.print(htmlBuilder.toString());
            out.flush();
            return;
        }

        // Load users list (for the initial page load)
        List<User> users = userDAO.getAllUsers();
        users.removeIf(u -> u.getId() == user.getId());

        request.setAttribute("messages", messages);
        request.setAttribute("users", users);

        request.getRequestDispatcher("/anon_inbox.jsp").forward(request, response);
    }
    
    // Simple utility to HTML-escape content for safety and display integrity
    private String htmlEscape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#x27;");
    }
    
    // Original escapeJson method is removed as it's no longer needed.
}