/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.HintDAO;
import com.secretsanta.models.Hint;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AdminHintServlet extends HttpServlet {

    private final HintDAO hintDAO = new HintDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Admin pages should redirect to JSP page, not stay empty
        response.sendRedirect(request.getContextPath() + "/admin/admin_hints.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Ensure user is logged in
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        // Ensure user is admin
        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Read parameters
        String userIdStr = request.getParameter("userId");
        String hintText = request.getParameter("hint");

        try {
            int userId = Integer.parseInt(userIdStr);

            if (hintText != null && !hintText.trim().isEmpty()) {
                hintDAO.addHint(new Hint(userId, hintText.trim()));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect to admin main hint page
        response.sendRedirect(request.getContextPath() + "/admin/admin_hints.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Admin Hint Management Servlet";
    }
}
