/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.UserDAO;
import com.secretsanta.models.User;
import com.secretsanta.utils.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

public class AdminUserServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User current = (session != null) ? (User) session.getAttribute("user") : null;

        if (current == null || !"admin".equalsIgnoreCase(current.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        List<User> users = userDAO.getAllUsers();
        request.setAttribute("users", users);
        request.getRequestDispatcher("/admin/admin_users.jsp").forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User current = (session != null) ? (User) session.getAttribute("user") : null;

        if (current == null || !"admin".equalsIgnoreCase(current.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) action = "list";

        try {
            if ("add".equalsIgnoreCase(action)) {

                String name = request.getParameter("name");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String role = request.getParameter("role");

                if (role == null || role.isEmpty()) role = "user";

                userDAO.register(new User(name, email, password, role));

                response.sendRedirect(request.getContextPath() + "/admin/admin_users.jsp");
                return;
            }
            if ("delete".equalsIgnoreCase(action)) {

                int id = Integer.parseInt(request.getParameter("id"));

                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement("DELETE FROM users WHERE id = ?")) {

                    ps.setInt(1, id);
                    ps.executeUpdate();
                }

                response.sendRedirect(request.getContextPath() + "/admin/admin_users.jsp");
                return;
            }
            if ("update".equalsIgnoreCase(action)) {

                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String role = request.getParameter("role");

                StringBuilder sql = new StringBuilder("UPDATE users SET ");
                boolean first = true;

                if (name != null && !name.isEmpty()) {
                    sql.append("name = ?");
                    first = false;
                }
                if (email != null && !email.isEmpty()) {
                    if (!first) sql.append(", ");
                    sql.append("email = ?");
                    first = false;
                }
                if (password != null && !password.isEmpty()) {
                    if (!first) sql.append(", ");
                    sql.append("password = ?");
                    first = false;
                }
                if (role != null && !role.isEmpty()) {
                    if (!first) sql.append(", ");
                    sql.append("role = ?");
                }

                sql.append(" WHERE id = ?");

                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement(sql.toString())) {

                    int idx = 1;
                    if (name != null && !name.isEmpty()) ps.setString(idx++, name);
                    if (email != null && !email.isEmpty()) ps.setString(idx++, email);
                    if (password != null && !password.isEmpty()) ps.setString(idx++, password);
                    if (role != null && !role.isEmpty()) ps.setString(idx++, role);

                    ps.setInt(idx, id);
                    ps.executeUpdate();
                }

                response.sendRedirect(request.getContextPath() + "/admin/admin_users.jsp");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Default → reload user list
        List<User> users = userDAO.getAllUsers();
        request.setAttribute("users", users);
        request.getRequestDispatcher("/admin/admin_users.jsp").forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Admin user manager servlet";
    }
}
