/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.WishlistDAO;
import com.secretsanta.models.User;
import com.secretsanta.models.WishlistItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class WishlistServlet extends HttpServlet {

    private final WishlistDAO wishlistDAO = new WishlistDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        List<WishlistItem> items = wishlistDAO.getUserWishlist(user.getId());
        request.setAttribute("wishlistItems", items);
        request.getRequestDispatcher("/wishlist.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String itemName = request.getParameter("itemName");
        String itemUrl = request.getParameter("itemUrl");
        String notes = request.getParameter("notes");

        if (itemName == null || itemName.trim().isEmpty()) {
            request.setAttribute("error", "Item name required.");
            doGet(request, response);
            return;
        }

        WishlistItem item = new WishlistItem(user.getId(), itemName.trim(), itemUrl, notes);
        wishlistDAO.addItem(item);
        response.sendRedirect(request.getContextPath() + "/WishlistServlet");
    }
}
