/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.secretsanta.servlets;

import com.secretsanta.dao.PollDAO;
import com.secretsanta.models.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class PollVoteServlet extends HttpServlet {

    private final PollDAO pollDAO = new PollDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Do NOT allow voting via GET → redirect
        response.sendRedirect("poll_view.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // -------- AUTH CHECK ----------
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // -------- VOTE PROCESS ----------
        String optionIdStr = request.getParameter("optionId");

        try {
            int optionId = Integer.parseInt(optionIdStr);
            pollDAO.voteOption(optionId);
        } catch (Exception ignored) {
            // invalid option ID — ignore
        }

        response.sendRedirect("poll_view.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Poll voting servlet";
    }
}
