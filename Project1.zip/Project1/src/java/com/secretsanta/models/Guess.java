/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
public class Guess {
    private int id;
    private int userId;
    private String guessedName;
    private boolean correct;

    public Guess() {}

    public Guess(int userId, String guessedName, boolean correct) {
        this.userId = userId;
        this.guessedName = guessedName;
        this.correct = correct;
    }

    public Guess(int id, int userId, String guessedName, boolean correct) {
        this.id = id;
        this.userId = userId;
        this.guessedName = guessedName;
        this.correct = correct;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getGuessedName() { return guessedName; }
    public void setGuessedName(String guessedName) { this.guessedName = guessedName; }

    public boolean isCorrect() { return correct; }
    public void setCorrect(boolean correct) { this.correct = correct; }
}
