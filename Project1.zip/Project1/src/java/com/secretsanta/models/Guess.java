/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
/*
 * In com.secretsanta.models package
 */
public class Guess {
    private int id;
    private int userId;
    private String guessedName;
    private Boolean correct; // <-- IMPORTANT: Boolean (nullable)

    public Guess() {}

    // Constructor for inserting a new guess (correct = null → pending)
    public Guess(int userId, String guessedName, Boolean correct) {
        this.userId = userId;
        this.guessedName = guessedName;
        this.correct = correct;
    }

    // Constructor for reading from database
    public Guess(int id, int userId, String guessedName, Boolean correct) {
        this.id = id;
        this.userId = userId;
        this.guessedName = guessedName;
        this.correct = correct;
    }

    // Getters & Setters
    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public int getUserId() { 
        return userId; 
    }
    public void setUserId(int userId) { 
        this.userId = userId; 
    }

    public String getGuessedName() { 
        return guessedName; 
    }
    public void setGuessedName(String guessedName) { 
        this.guessedName = guessedName; 
    }

    public Boolean getCorrect() { 
        return correct; 
    }
    public void setCorrect(Boolean correct) { 
        this.correct = correct; 
    }
}