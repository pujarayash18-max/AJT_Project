/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */




import java.sql.Timestamp;

public class ChallengeSubmission {

    private int userId;
    private int challengeId;
    private String submissionText;
    private Timestamp submittedAt;

    // Constructor for new submissions
    public ChallengeSubmission(int userId, int challengeId, String submissionText) {
        this.userId = userId;
        this.challengeId = challengeId;
        this.submissionText = submissionText;
    }

    // Constructor when reading from database
    public ChallengeSubmission(int userId, int challengeId, String submissionText, Timestamp submittedAt) {
        this.userId = userId;
        this.challengeId = challengeId;
        this.submissionText = submissionText;
        this.submittedAt = submittedAt;
    }

    public int getUserId() { return userId; }
    public int getChallengeId() { return challengeId; }
    public String getSubmissionText() { return submissionText; }
    public Timestamp getSubmittedAt() { return submittedAt; }

    public void setSubmittedAt(Timestamp submittedAt) { this.submittedAt = submittedAt; }
}
