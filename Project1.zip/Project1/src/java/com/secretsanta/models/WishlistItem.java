/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
public class WishlistItem {
    private int id;
    private int userId;
    private String itemName;
    private String itemUrl;
    private String notes;

    public WishlistItem() {}

    public WishlistItem(int id, int userId, String itemName, String itemUrl, String notes) {
        this.id = id;
        this.userId = userId;
        this.itemName = itemName;
        this.itemUrl = itemUrl;
        this.notes = notes;
    }

    public WishlistItem(int userId, String itemName, String itemUrl, String notes) {
        this.userId = userId;
        this.itemName = itemName;
        this.itemUrl = itemUrl;
        this.notes = notes;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public String getItemUrl() { return itemUrl; }
    public void setItemUrl(String itemUrl) { this.itemUrl = itemUrl; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    @Override
    public String toString() {
        return "WishlistItem{id=" + id + ", userId=" + userId + ", itemName=" + itemName + "}";
    }
}
