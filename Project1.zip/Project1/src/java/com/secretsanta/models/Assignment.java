/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
public class Assignment {
    private int id;
    private int giverId;
    private int receiverId;

    public Assignment() {}

    public Assignment(int giverId, int receiverId) {
        this.giverId = giverId;
        this.receiverId = receiverId;
    }

    public Assignment(int id, int giverId, int receiverId) {
        this.id = id;
        this.giverId = giverId;
        this.receiverId = receiverId;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getGiverId() { return giverId; }
    public void setGiverId(int giverId) { this.giverId = giverId; }

    public int getReceiverId() { return receiverId; }
    public void setReceiverId(int receiverId) { this.receiverId = receiverId; }
}