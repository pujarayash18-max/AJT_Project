/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
public class Story {
    private int id;
    private int userId;
    private String storyText;

    public Story() {}

    public Story(int userId, String storyText) {
        this.userId = userId;
        this.storyText = storyText;
    }

    public Story(int id, int userId, String storyText) {
        this.id = id;
        this.userId = userId;
        this.storyText = storyText;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getStoryText() { return storyText; }
    public void setStoryText(String storyText) { this.storyText = storyText; }
}
