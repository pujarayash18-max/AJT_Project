/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */


public class PollOption {

    private int id;
    private int pollId;
    private String optionText;   // ⭐ renamed from "text"
    private int votes;

    public PollOption() {}

    public PollOption(int pollId, String optionText) {
        this.pollId = pollId;
        this.optionText = optionText;
    }

    public PollOption(int id, int pollId, String optionText, int votes) {
        this.id = id;
        this.pollId = pollId;
        this.optionText = optionText;
        this.votes = votes;
    }

    // Getters & setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPollId() { return pollId; }
    public void setPollId(int pollId) { this.pollId = pollId; }

    public String getOptionText() { return optionText; }
    public void setOptionText(String optionText) { this.optionText = optionText; }

    public int getVotes() { return votes; }
    public void setVotes(int votes) { this.votes = votes; }
}
