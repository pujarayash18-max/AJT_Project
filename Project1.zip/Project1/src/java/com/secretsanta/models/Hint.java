/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.secretsanta.models;

/**
 *
 * @author yash
 */
public class Hint {
    private int id;
    private int userId;
    private String hintText;

    public Hint() {}

    public Hint(int userId, String hintText) {
        this.userId = userId;
        this.hintText = hintText;
    }

    public Hint(int id, int userId, String hintText) {
        this.id = id;
        this.userId = userId;
        this.hintText = hintText;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getHintText() { return hintText; }
    public void setHintText(String hintText) { this.hintText = hintText; }
}
