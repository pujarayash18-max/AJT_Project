package com.secretsanta.models;

public class Poll {

    private int id;
    private String question;
    private String description;

    public Poll() {
    }

    public Poll(int id, String question, String description) {
        this.id = id;
        this.question = question;
        this.description = description;
    }

    public Poll(String question, String description) {
        this.question = question;
        this.description = description;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}