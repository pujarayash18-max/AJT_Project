/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.santa.dao;

/**
 *
 * @author yash
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private static Connection con;

    public static Connection getConnection() {
        try {
            System.out.println("🟡 Attempting to load MySQL driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✅ Driver loaded successfully.");

            String url = "jdbc:mysql://localhost:3306/secretsanta"; // Change DB name
            String user = "root"; // Change username if needed
            String pass = "YashPujara@18"; // Change password ("" if none)

            System.out.println("🟡 Attempting to connect to database...");
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("✅ Database connected successfully!");
        } 
        catch (ClassNotFoundException e) {
            System.out.println("❌ JDBC Driver not found! Make sure mysql-connector-j.jar is in WEB-INF/lib");
            e.printStackTrace();
        } 
        catch (SQLException e) {
            System.out.println("❌ SQL Connection failed!");
            e.printStackTrace();
        } 
        catch (Exception e) {
            System.out.println("❌ Unexpected error:");
            e.printStackTrace();
        }
        return con;
    }
}