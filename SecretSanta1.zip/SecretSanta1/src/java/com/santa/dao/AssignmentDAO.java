/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.santa.dao;


import java.sql.*;
import java.util.*;
/**
 *
 * @author yash
 */
public class AssignmentDAO {
    public static void assignRandomly() {
        try (Connection con = ConnectionFactory.getConnection()) {
            // Fetch all users
            List<Integer> ids = new ArrayList<>();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT id FROM users");
            while (rs.next()) {
                ids.add(rs.getInt(1));
            }

            // Shuffle list randomly
            Collections.shuffle(ids);

            // Clear previous assignments
            st.executeUpdate("DELETE FROM assignments");

            // Assign next person in the list
            for (int i = 0; i < ids.size(); i++) {
                int giver = ids.get(i);
                int receiver = ids.get((i + 1) % ids.size());
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO assignments (giver_id, receiver_id) VALUES (?, ?)");
                ps.setInt(1, giver);
                ps.setInt(2, receiver);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getReceiverName(int giverId) {
        String name = null;
        try (Connection con = ConnectionFactory.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT u.name FROM assignments a JOIN users u ON a.receiver_id = u.id WHERE a.giver_id = ?");
            ps.setInt(1, giverId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return name;
    }
    
}
