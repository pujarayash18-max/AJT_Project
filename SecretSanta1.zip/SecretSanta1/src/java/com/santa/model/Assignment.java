/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.santa.model;

/**
 *
 * @author yash
 */
public class Assignment {
    private int giverId;
    private int receiverId;

    // --- Constructors ---
    public Assignment() {}

    public Assignment(int giverId, int receiverId) {
        this.giverId = giverId;
        this.receiverId = receiverId;
    }

    // --- Getters and Setters ---
    public int getGiverId() {
        return giverId;
    }

    public void setGiverId(int giverId) {
        this.giverId = giverId;
    }

    public int getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(int receiverId) {
        this.receiverId = receiverId;
    }

    // --- toString (optional for debugging) ---
    @Override
    public String toString() {
        return "Assignment [giverId=" + giverId + ", receiverId=" + receiverId + "]";
    }
    
}
